#!/usr/bin/env python3
"""
UI Assets Generator for SomnaSync Pro
Generates high-quality placeholder images for app logo, onboarding, and backgrounds
"""

from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os
import math

def create_app_logo(size=512):
    """Create a high-quality app logo for SomnaSync Pro"""
    # Create a new image with transparent background
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Create gradient background (dark blue to purple)
    for y in range(size):
        r = int(20 + (y / size) * 30)
        g = int(30 + (y / size) * 20)
        b = int(80 + (y / size) * 60)
        color = (r, g, b, 255)
        draw.line([(0, y), (size, y)], fill=color)
    
    # Add moon shape (white circle with glow effect)
    moon_center = (size // 2, size // 3)
    moon_radius = size // 4
    
    # Create glow effect
    for i in range(10):
        glow_radius = moon_radius + i * 2
        glow_alpha = 50 - i * 5
        glow_color = (255, 255, 255, max(0, glow_alpha))
        draw.ellipse([
            moon_center[0] - glow_radius,
            moon_center[1] - glow_radius,
            moon_center[0] + glow_radius,
            moon_center[1] + glow_radius
        ], fill=glow_color)
    
    # Main moon
    moon_color = (255, 255, 255, 220)
    draw.ellipse([
        moon_center[0] - moon_radius,
        moon_center[1] - moon_radius,
        moon_center[0] + moon_radius,
        moon_center[1] + moon_radius
    ], fill=moon_color)
    
    # Add stars with glow
    star_positions = [
        (size // 4, size // 6),
        (3 * size // 4, size // 8),
        (size // 6, size // 2),
        (5 * size // 6, size // 3),
        (size // 3, 2 * size // 3),
        (2 * size // 3, 3 * size // 4)
    ]
    
    for star_pos in star_positions:
        # Star glow
        for i in range(5):
            glow_radius = size // 40 + i
            glow_alpha = 100 - i * 20
            glow_color = (255, 255, 255, max(0, glow_alpha))
            draw.ellipse([
                star_pos[0] - glow_radius,
                star_pos[1] - glow_radius,
                star_pos[0] + glow_radius,
                star_pos[1] + glow_radius
            ], fill=glow_color)
        
        # Main star
        star_radius = size // 40
        draw.ellipse([
            star_pos[0] - star_radius,
            star_pos[1] - star_radius,
            star_pos[0] + star_radius,
            star_pos[1] + star_radius
        ], fill=(255, 255, 255, 200))
    
    # Add sleep waves with glow
    wave_center_y = 3 * size // 4
    wave_height = size // 20
    
    for i in range(3):
        y_offset = wave_center_y + i * size // 30
        wave_color = (255, 255, 255, 120 - i * 30)
        
        # Wave glow
        for glow in range(3):
            glow_y = y_offset + glow
            glow_alpha = 60 - glow * 20
            glow_color = (255, 255, 255, max(0, glow_alpha))
            
            points = []
            for x in range(0, size, size // 20):
                wave_x = x
                wave_y = glow_y + wave_height * (i + 1) * 0.3 * (1 if x % (size // 10) < size // 20 else -1)
                points.append((wave_x, wave_y))
            
            if len(points) > 1:
                draw.line(points, fill=glow_color, width=size // 80)
        
        # Main wave
        points = []
        for x in range(0, size, size // 20):
            wave_x = x
            wave_y = y_offset + wave_height * (i + 1) * 0.3 * (1 if x % (size // 10) < size // 20 else -1)
            points.append((wave_x, wave_y))
        
        if len(points) > 1:
            draw.line(points, fill=wave_color, width=size // 100)
    
    # Add "SS" text with glow
    try:
        font_size = size // 6
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", font_size)
    except:
        font = ImageFont.load_default()
    
    text = "SS"
    text_bbox = draw.textbbox((0, 0), text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    
    text_x = (size - text_width) // 2
    text_y = 4 * size // 5
    
    # Text glow
    for i in range(5):
        glow_x = text_x + i
        glow_y = text_y + i
        glow_color = (255, 255, 255, 100 - i * 20)
        draw.text((glow_x, glow_y), text, fill=glow_color, font=font)
    
    # Main text
    text_color = (255, 255, 255, 240)
    draw.text((text_x, text_y), text, fill=text_color, font=font)
    
    return img

def create_onboarding_image(index, size=(800, 600)):
    """Create onboarding images for different screens"""
    img = Image.new('RGBA', size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Create gradient background
    for y in range(size[1]):
        r = int(10 + (y / size[1]) * 40)
        g = int(15 + (y / size[1]) * 30)
        b = int(40 + (y / size[1]) * 80)
        color = (r, g, b, 255)
        draw.line([(0, y), (size[0], y)], fill=color)
    
    # Add different illustrations based on index
    if index == 1:  # AI Brain
        # Draw brain-like structure
        center_x, center_y = size[0] // 2, size[1] // 3
        radius = min(size) // 6
        
        # Brain outline
        brain_color = (100, 150, 255, 200)
        for i in range(radius, 0, -2):
            alpha = 200 - (radius - i) * 2
            color = (100, 150, 255, max(0, alpha))
            draw.ellipse([center_x - i, center_y - i, center_x + i, center_y + i], fill=color)
        
        # Neural connections
        for _ in range(20):
            x1 = center_x + (radius - 20) * math.cos(_ * 0.3)
            y1 = center_y + (radius - 20) * math.sin(_ * 0.3)
            x2 = center_x + (radius + 20) * math.cos(_ * 0.5)
            y2 = center_y + (radius + 20) * math.sin(_ * 0.5)
            draw.line([(x1, y1), (x2, y2)], fill=(255, 255, 255, 100), width=2)
        
        # Add text
        text = "AI-Powered Sleep Analysis"
        try:
            font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 32)
        except:
            font = ImageFont.load_default()
        
        text_bbox = draw.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_x = (size[0] - text_width) // 2
        text_y = 2 * size[1] // 3
        
        draw.text((text_x, text_y), text, fill=(255, 255, 255, 240), font=font)
        
    elif index == 2:  # Sleep Tracking
        # Draw bed with sleep waves
        bed_x, bed_y = size[0] // 2, size[1] // 2
        bed_width, bed_height = size[0] // 3, size[1] // 4
        
        # Bed frame
        draw.rectangle([bed_x - bed_width//2, bed_y - bed_height//2, 
                       bed_x + bed_width//2, bed_y + bed_height//2], 
                      fill=(80, 80, 120, 200))
        
        # Sleep waves above bed
        for i in range(5):
            y_offset = bed_y - bed_height//2 - 20 - i * 10
            wave_color = (255, 255, 255, 150 - i * 20)
            
            points = []
            for x in range(bed_x - bed_width//2, bed_x + bed_width//2, 10):
                wave_y = y_offset + 5 * math.sin((x - bed_x) * 0.1)
                points.append((x, wave_y))
            
            if len(points) > 1:
                draw.line(points, fill=wave_color, width=2)
        
        # Add text
        text = "Comprehensive Sleep Tracking"
        try:
            font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 28)
        except:
            font = ImageFont.load_default()
        
        text_bbox = draw.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_x = (size[0] - text_width) // 2
        text_y = bed_y + bed_height//2 + 50
        
        draw.text((text_x, text_y), text, fill=(255, 255, 255, 240), font=font)
        
    elif index == 3:  # Smart Alarm
        # Draw alarm clock with brain
        clock_x, clock_y = size[0] // 2, size[1] // 2
        clock_radius = min(size) // 8
        
        # Clock face
        draw.ellipse([clock_x - clock_radius, clock_y - clock_radius,
                     clock_x + clock_radius, clock_y + clock_radius],
                    fill=(60, 60, 80, 200))
        
        # Clock hands
        draw.line([(clock_x, clock_y), (clock_x, clock_y - clock_radius + 10)], 
                 fill=(255, 255, 255, 200), width=3)
        draw.line([(clock_x, clock_y), (clock_x + clock_radius - 20, clock_y)], 
                 fill=(255, 255, 255, 200), width=2)
        
        # Brain icon next to clock
        brain_x = clock_x + clock_radius + 50
        brain_y = clock_y
        brain_radius = clock_radius // 2
        
        for i in range(brain_radius, 0, -2):
            alpha = 200 - (brain_radius - i) * 3
            color = (100, 150, 255, max(0, alpha))
            draw.ellipse([brain_x - i, brain_y - i, brain_x + i, brain_y + i], fill=color)
        
        # Add text
        text = "Smart Alarm Optimization"
        try:
            font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 28)
        except:
            font = ImageFont.load_default()
        
        text_bbox = draw.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_x = (size[0] - text_width) // 2
        text_y = clock_y + clock_radius + 50
        
        draw.text((text_x, text_y), text, fill=(255, 255, 255, 240), font=font)
    
    return img

def create_background_image(size=(1200, 800)):
    """Create a beautiful background image for the app"""
    img = Image.new('RGBA', size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Create deep space-like gradient
    for y in range(size[1]):
        # Deep blue to purple gradient
        r = int(5 + (y / size[1]) * 20)
        g = int(10 + (y / size[1]) * 15)
        b = int(30 + (y / size[1]) * 60)
        color = (r, g, b, 255)
        draw.line([(0, y), (size[0], y)], fill=color)
    
    # Add stars
    for _ in range(100):
        x = int(size[0] * 0.1 + (size[0] * 0.8) * (_ % 10) / 10)
        y = int(size[1] * 0.1 + (size[1] * 0.8) * (_ // 10) / 10)
        
        # Random star brightness
        brightness = 100 + (_ % 3) * 50
        star_color = (255, 255, 255, brightness)
        
        # Star with glow
        for i in range(3):
            glow_radius = 1 + i
            glow_alpha = brightness - i * 30
            glow_color = (255, 255, 255, max(0, glow_alpha))
            draw.ellipse([x - glow_radius, y - glow_radius, x + glow_radius, y + glow_radius], 
                        fill=glow_color)
    
    # Add subtle nebula-like clouds
    for _ in range(5):
        cloud_x = int(size[0] * (0.2 + 0.6 * (_ % 3) / 3))
        cloud_y = int(size[1] * (0.3 + 0.4 * (_ // 3) / 2))
        cloud_radius = 50 + (_ % 3) * 30
        
        for i in range(cloud_radius, 0, -5):
            alpha = int(30 - (cloud_radius - i) * 0.5)
            color = (100, 80, 150, max(0, alpha))
            draw.ellipse([cloud_x - i, cloud_y - i, cloud_x + i, cloud_y + i], fill=color)
    
    return img

def generate_ui_assets():
    """Generate all UI assets"""
    # Create assets directory
    assets_dir = "SomnaSync/Images.xcassets"
    os.makedirs(assets_dir, exist_ok=True)
    
    print("Generating UI assets...")
    
    # 1. App Logo
    logo_dir = os.path.join(assets_dir, "AppLogo.imageset")
    os.makedirs(logo_dir, exist_ok=True)
    
    logo = create_app_logo(512)
    logo.save(os.path.join(logo_dir, "AppLogo.png"), "PNG")
    
    # Create Contents.json for logo
    logo_contents = {
        "images": [
            {
                "filename": "AppLogo.png",
                "idiom": "universal",
                "scale": "1x"
            }
        ],
        "info": {
            "author": "xcode",
            "version": 1
        }
    }
    
    import json
    with open(os.path.join(logo_dir, "Contents.json"), "w") as f:
        json.dump(logo_contents, f, indent=2)
    
    print("Generated: AppLogo.png")
    
    # 2. Onboarding Images
    onboarding_dir = os.path.join(assets_dir, "Onboarding.imageset")
    os.makedirs(onboarding_dir, exist_ok=True)
    
    for i in range(1, 4):
        onboarding_img = create_onboarding_image(i)
        filename = f"Onboarding_{i}.png"
        onboarding_img.save(os.path.join(onboarding_dir, filename), "PNG")
        print(f"Generated: {filename}")
    
    # Create Contents.json for onboarding
    onboarding_contents = {
        "images": [
            {
                "filename": "Onboarding_1.png",
                "idiom": "universal",
                "scale": "1x"
            },
            {
                "filename": "Onboarding_2.png",
                "idiom": "universal",
                "scale": "1x"
            },
            {
                "filename": "Onboarding_3.png",
                "idiom": "universal",
                "scale": "1x"
            }
        ],
        "info": {
            "author": "xcode",
            "version": 1
        }
    }
    
    with open(os.path.join(onboarding_dir, "Contents.json"), "w") as f:
        json.dump(onboarding_contents, f, indent=2)
    
    # 3. Background Image
    background_dir = os.path.join(assets_dir, "Background.imageset")
    os.makedirs(background_dir, exist_ok=True)
    
    background = create_background_image()
    background.save(os.path.join(background_dir, "Background.png"), "PNG")
    
    # Create Contents.json for background
    background_contents = {
        "images": [
            {
                "filename": "Background.png",
                "idiom": "universal",
                "scale": "1x"
            }
        ],
        "info": {
            "author": "xcode",
            "version": 1
        }
    }
    
    with open(os.path.join(background_dir, "Contents.json"), "w") as f:
        json.dump(background_contents, f, indent=2)
    
    print("Generated: Background.png")
    
    print(f"\nAll UI assets generated in: {assets_dir}")
    print("Total assets generated: 6 (AppLogo, 3 Onboarding images, Background)")

if __name__ == "__main__":
    generate_ui_assets() 