#!/usr/bin/env python3
"""
SomnaSync Pro - High Quality Audio Generator
===========================================

Generates high-quality audio files for sleep optimization and meditation.
Focuses on quality over quantity with shorter, well-crafted audio files.

Usage:
    python3 generate_audio_quality.py

Output:
    - High-quality WAV audio files
    - Optimized for sleep and meditation
    - Professional-grade audio generation
"""

import os
import math
import wave
import struct
import random
from pathlib import Path

class QualityAudioGenerator:
    def __init__(self, sample_rate=48000, bit_depth=24):
        self.sample_rate = sample_rate
        self.bit_depth = bit_depth
        self.output_dir = Path("QualityAudio")
        self.output_dir.mkdir(exist_ok=True)
        
        # Create subdirectories
        self.dirs = {
            'binaural': self.output_dir / "BinauralBeats",
            'white_noise': self.output_dir / "WhiteNoise", 
            'nature': self.output_dir / "NatureSounds",
            'meditation': self.output_dir / "Meditation",
            'sleep': self.output_dir / "SleepAudio",
            'ambient': self.output_dir / "AmbientMusic"
        }
        
        for dir_path in self.dirs.values():
            dir_path.mkdir(exist_ok=True)
    
    def write_wav_file(self, filename, left_channel, right_channel):
        """Write high-quality stereo audio data to WAV file"""
        with wave.open(str(filename), 'w') as wav_file:
            # Set parameters for high quality
            wav_file.setnchannels(2)  # Stereo
            wav_file.setsampwidth(self.bit_depth // 8)  # Bytes per sample
            wav_file.setframerate(self.sample_rate)
            
            # Combine channels and write with high precision
            for i in range(len(left_channel)):
                # Convert to 24-bit integers for higher quality
                left_sample = int(left_channel[i] * 8388607)  # 2^23 - 1
                right_sample = int(right_channel[i] * 8388607)
                
                # Pack as little-endian 24-bit integers
                data = struct.pack('<ii', left_sample, right_sample)
                wav_file.writeframes(data)
    
    def apply_fade(self, samples, fade_in_duration, fade_out_duration):
        """Apply smooth fade in/out to audio samples"""
        fade_in_samples = int(fade_in_duration * self.sample_rate)
        fade_out_samples = int(fade_out_duration * self.sample_rate)
        
        # Apply fade in (smooth curve)
        for i in range(min(fade_in_samples, len(samples))):
            fade_factor = (1 - math.cos(math.pi * i / fade_in_samples)) / 2
            samples[i] *= fade_factor
        
        # Apply fade out (smooth curve)
        for i in range(min(fade_out_samples, len(samples))):
            fade_factor = (1 - math.cos(math.pi * i / fade_out_samples)) / 2
            samples[-(i+1)] *= fade_factor
        
        return samples
    
    def generate_binaural_beats(self, base_freq=200, beat_freq=10, duration=600, filename="binaural_10hz"):
        """Generate high-quality binaural beats"""
        print(f"Generating binaural beats: {beat_freq}Hz for {duration}s")
        
        num_samples = int(self.sample_rate * duration)
        left_channel = []
        right_channel = []
        
        # Generate left and right channel frequencies
        left_freq = base_freq
        right_freq = base_freq + beat_freq
        
        for i in range(num_samples):
            t = i / self.sample_rate
            
            # Create rich sine waves with harmonics
            left_sample = 0.25 * math.sin(2 * math.pi * left_freq * t)
            right_sample = 0.25 * math.sin(2 * math.pi * right_freq * t)
            
            # Add harmonics for richer sound
            harmonics = [0.5, 0.25, 0.125, 0.0625]
            harmonic_amps = [0.15, 0.1, 0.05, 0.025]
            
            for harmonic, amp in zip(harmonics, harmonic_amps):
                left_sample += amp * math.sin(2 * math.pi * left_freq * harmonic * t)
                right_sample += amp * math.sin(2 * math.pi * right_freq * harmonic * t)
            
            # Add subtle modulation for natural feel
            modulation = 1.0 + 0.05 * math.sin(2 * math.pi * 0.1 * t)
            left_sample *= modulation
            right_sample *= modulation
            
            left_channel.append(left_sample)
            right_channel.append(right_sample)
        
        # Apply smooth fades
        left_channel = self.apply_fade(left_channel, 30, 30)
        right_channel = self.apply_fade(right_channel, 30, 30)
        
        # Save as WAV
        output_path = self.dirs['binaural'] / f"{filename}.wav"
        self.write_wav_file(output_path, left_channel, right_channel)
        print(f"Saved: {output_path}")
        
        return output_path
    
    def generate_white_noise(self, color='white', duration=600, filename="white_noise"):
        """Generate high-quality colored noise"""
        print(f"Generating {color} noise for {duration}s")
        
        num_samples = int(self.sample_rate * duration)
        left_channel = []
        right_channel = []
        
        # Initialize filters for colored noise
        if color == 'pink':
            # Pink noise filter coefficients
            b0, b1, b2, b3, b4, b5, b6 = 0.99886, 0.99332, 0.96900, 0.86650, 0.55000, -0.7616, 0.0
            a0, a1, a2, a3, a4, a5, a6 = 0.0555179, 0.0750759, 0.1538520, 0.3104856, 0.5329522, -0.0168980, 0.0
            
            # Initialize filter states
            x = [0.0] * 7
            y = [0.0] * 7
        
        for i in range(num_samples):
            if color == 'white':
                # Pure white noise
                left_sample = random.uniform(-0.2, 0.2)
                right_sample = random.uniform(-0.2, 0.2)
            
            elif color == 'pink':
                # Pink noise using 7-pole filter
                white = random.uniform(-1.0, 1.0)
                
                # Apply filter
                x[0] = white
                y[0] = b0 * x[0] + b1 * x[1] + b2 * x[2] + b3 * x[3] + b4 * x[4] + b5 * x[5] + b6 * x[6]
                y[0] -= a1 * y[1] + a2 * y[2] + a3 * y[3] + a4 * y[4] + a5 * y[5] + a6 * y[6]
                
                left_sample = y[0] * 0.15
                right_sample = y[0] * 0.15
                
                # Shift filter states
                for j in range(6, 0, -1):
                    x[j] = x[j-1]
                    y[j] = y[j-1]
            
            elif color == 'brown':
                # Brown noise (1/f^2) using integration
                white = random.uniform(-1.0, 1.0)
                left_sample = white * 0.1 * (1.0 - i / num_samples)
                right_sample = white * 0.1 * (1.0 - i / num_samples)
            
            # Add subtle stereo separation
            left_channel.append(left_sample)
            right_channel.append(right_sample * 0.95 + 0.05 * random.uniform(-0.1, 0.1))
        
        # Apply smooth fades
        left_channel = self.apply_fade(left_channel, 30, 30)
        right_channel = self.apply_fade(right_channel, 30, 30)
        
        # Save as WAV
        output_path = self.dirs['white_noise'] / f"{filename}_{color}.wav"
        self.write_wav_file(output_path, left_channel, right_channel)
        print(f"Saved: {output_path}")
        
        return output_path
    
    def generate_ocean_waves(self, duration=600, filename="ocean_waves"):
        """Generate realistic ocean wave sounds"""
        print(f"Generating ocean waves for {duration}s")
        
        num_samples = int(self.sample_rate * duration)
        left_channel = []
        right_channel = []
        
        # Initialize wave phases
        wave1_phase = 0
        wave2_phase = math.pi / 4
        wave3_phase = math.pi / 2
        
        for i in range(num_samples):
            t = i / self.sample_rate
            
            # Multiple wave layers with different frequencies
            wave1 = 0.25 * math.sin(2 * math.pi * 0.08 * t + wave1_phase)  # Slow waves
            wave2 = 0.18 * math.sin(2 * math.pi * 0.12 * t + wave2_phase)  # Medium waves
            wave3 = 0.12 * math.sin(2 * math.pi * 0.16 * t + wave3_phase)  # Fast waves
            
            # Add wave breaking sounds
            breaking_chance = (math.sin(2 * math.pi * 0.02 * t) + 1) / 2
            if breaking_chance > 0.85:
                breaking_noise = random.uniform(-0.15, 0.15)
                breaking_envelope = math.exp(-t * 0.5) * 0.2
                breaking_sound = breaking_noise * breaking_envelope
            else:
                breaking_sound = 0
            
            # Combine waves
            ocean_sound = wave1 + wave2 + wave3 + breaking_sound
            
            # Add subtle variations for realism
            variation = 0.05 * math.sin(2 * math.pi * 0.03 * t)
            ocean_sound += variation
            
            # Create stereo with spatial effect
            left_sample = ocean_sound
            right_sample = ocean_sound * 0.9 + 0.1 * random.uniform(-0.05, 0.05)
            
            left_channel.append(left_sample)
            right_channel.append(right_sample)
            
            # Update phases slowly
            wave1_phase += 0.001
            wave2_phase += 0.0015
            wave3_phase += 0.002
        
        # Apply smooth fades
        left_channel = self.apply_fade(left_channel, 30, 30)
        right_channel = self.apply_fade(right_channel, 30, 30)
        
        # Save as WAV
        output_path = self.dirs['nature'] / f"{filename}.wav"
        self.write_wav_file(output_path, left_channel, right_channel)
        print(f"Saved: {output_path}")
        
        return output_path
    
    def generate_rain_sounds(self, duration=600, filename="rain_sounds"):
        """Generate realistic rain sounds"""
        print(f"Generating rain sounds for {duration}s")
        
        num_samples = int(self.sample_rate * duration)
        left_channel = []
        right_channel = []
        
        # Rain drop parameters
        drop_frequencies = [0.1, 0.15, 0.08, 0.12]
        drop_amplitudes = [0.08, 0.06, 0.04, 0.05]
        
        for i in range(num_samples):
            t = i / self.sample_rate
            
            # Generate multiple rain drop layers
            rain_sound = 0
            for freq, amp in zip(drop_frequencies, drop_amplitudes):
                drop_chance = (math.sin(2 * math.pi * freq * t) + 1) / 2
                if drop_chance > 0.8:
                    # Create drop sound
                    drop_freq = 200 + 100 * random.random()
                    drop_duration = 0.1 + 0.05 * random.random()
                    drop_samples = int(drop_duration * self.sample_rate)
                    
                    if i < num_samples - drop_samples:
                        drop_envelope = math.exp(-t * 2.0)
                        drop_sound = amp * math.sin(2 * math.pi * drop_freq * t) * drop_envelope
                        rain_sound += drop_sound
            
            # Add occasional thunder
            thunder_chance = (math.sin(2 * math.pi * 0.001 * t) + 1) / 2
            if thunder_chance > 0.995:
                thunder_freq = 50 + 30 * random.random()
                thunder_duration = 2.0
                thunder_samples = int(thunder_duration * self.sample_rate)
                
                if i < num_samples - thunder_samples:
                    thunder_envelope = math.exp(-t * 0.1)
                    thunder_sound = 0.3 * math.sin(2 * math.pi * thunder_freq * t) * thunder_envelope
                    rain_sound += thunder_sound
            
            # Create stereo
            left_sample = rain_sound
            right_sample = rain_sound * 0.95 + 0.05 * random.uniform(-0.02, 0.02)
            
            left_channel.append(left_sample)
            right_channel.append(right_sample)
        
        # Apply smooth fades
        left_channel = self.apply_fade(left_channel, 30, 30)
        right_channel = self.apply_fade(right_channel, 30, 30)
        
        # Save as WAV
        output_path = self.dirs['nature'] / f"{filename}.wav"
        self.write_wav_file(output_path, left_channel, right_channel)
        print(f"Saved: {output_path}")
        
        return output_path
    
    def generate_meditation_bells(self, duration=600, filename="meditation_bells"):
        """Generate meditation bell sounds with sacred frequencies"""
        print(f"Generating meditation bells for {duration}s")
        
        num_samples = int(self.sample_rate * duration)
        left_channel = []
        right_channel = []
        
        # Sacred frequencies for meditation
        frequencies = [432, 528, 640, 741, 852]  # Hz
        amplitudes = [0.12, 0.10, 0.08, 0.06, 0.04]
        
        for i in range(num_samples):
            t = i / self.sample_rate
            
            # Generate bell tones
            bell_sound = 0
            for freq, amp in zip(frequencies, amplitudes):
                bell_sound += amp * math.sin(2 * math.pi * freq * t)
            
            # Add harmonics for bell-like quality
            harmonics = [2, 3, 4, 5]
            for harmonic in harmonics:
                bell_sound += 0.02 * math.sin(2 * math.pi * 432 * harmonic * t)
            
            # Bell envelope (slow decay with resonance)
            bell_envelope = math.exp(-t * 0.05) * (1 + 0.3 * math.sin(2 * math.pi * 0.02 * t))
            bell_sound *= bell_envelope
            
            # Create stereo with slight separation
            left_sample = bell_sound
            right_sample = bell_sound * 0.98
            
            left_channel.append(left_sample)
            right_channel.append(right_sample)
        
        # Apply smooth fades
        left_channel = self.apply_fade(left_channel, 30, 30)
        right_channel = self.apply_fade(right_channel, 30, 30)
        
        # Save as WAV
        output_path = self.dirs['meditation'] / f"{filename}.wav"
        self.write_wav_file(output_path, left_channel, right_channel)
        print(f"Saved: {output_path}")
        
        return output_path
    
    def generate_breathing_guide(self, duration=600, filename="breathing_guide"):
        """Generate breathing guide with natural rhythm"""
        print(f"Generating breathing guide for {duration}s")
        
        num_samples = int(self.sample_rate * duration)
        left_channel = []
        right_channel = []
        
        # Breathing parameters (6 breaths per minute)
        breath_freq = 0.1  # 6 breaths per minute
        inhale_ratio = 0.4  # 40% inhale, 60% exhale
        
        for i in range(num_samples):
            t = i / self.sample_rate
            
            # Create breathing rhythm
            breath_cycle = math.sin(2 * math.pi * breath_freq * t)
            
            # Different envelopes for inhale and exhale
            if breath_cycle > 0:  # Inhale
                envelope = math.sin(math.pi * breath_cycle / 2)
            else:  # Exhale
                envelope = math.sin(math.pi * (1 + breath_cycle) / 2)
            
            # Breathing tone with harmonics
            base_freq = 200
            breath_tone = 0.08 * math.sin(2 * math.pi * base_freq * t)
            breath_tone += 0.04 * math.sin(2 * math.pi * base_freq * 2 * t)
            breath_tone += 0.02 * math.sin(2 * math.pi * base_freq * 3 * t)
            
            # Apply breathing envelope
            breath_sound = breath_tone * envelope
            
            # Create stereo
            left_sample = breath_sound
            right_sample = breath_sound * 0.95
            
            left_channel.append(left_sample)
            right_channel.append(right_sample)
        
        # Apply smooth fades
        left_channel = self.apply_fade(left_channel, 30, 30)
        right_channel = self.apply_fade(right_channel, 30, 30)
        
        # Save as WAV
        output_path = self.dirs['meditation'] / f"{filename}.wav"
        self.write_wav_file(output_path, left_channel, right_channel)
        print(f"Saved: {output_path}")
        
        return output_path
    
    def generate_ambient_drone(self, duration=600, filename="ambient_drone"):
        """Generate ambient drone music"""
        print(f"Generating ambient drone for {duration}s")
        
        num_samples = int(self.sample_rate * duration)
        left_channel = []
        right_channel = []
        
        # Drone frequencies (harmonious intervals)
        drone_freqs = [110, 220, 440, 880]  # A2, A3, A4, A5
        drone_amps = [0.10, 0.08, 0.06, 0.04]
        
        for i in range(num_samples):
            t = i / self.sample_rate
            
            # Generate layered drone
            drone_sound = 0
            for freq, amp in zip(drone_freqs, drone_amps):
                drone_sound += amp * math.sin(2 * math.pi * freq * t)
            
            # Add slow modulation for movement
            modulation = 1.0 + 0.1 * math.sin(2 * math.pi * 0.01 * t)
            drone_sound *= modulation
            
            # Add subtle filter sweep
            filter_freq = 0.5 + 0.3 * math.sin(2 * math.pi * 0.005 * t)
            drone_sound *= filter_freq
            
            # Create stereo with spatial effect
            left_sample = drone_sound
            right_sample = drone_sound * 0.9 + 0.1 * random.uniform(-0.02, 0.02)
            
            left_channel.append(left_sample)
            right_channel.append(right_sample)
        
        # Apply smooth fades
        left_channel = self.apply_fade(left_channel, 30, 30)
        right_channel = self.apply_fade(right_channel, 30, 30)
        
        # Save as WAV
        output_path = self.dirs['ambient'] / f"{filename}.wav"
        self.write_wav_file(output_path, left_channel, right_channel)
        print(f"Saved: {output_path}")
        
        return output_path
    
    def generate_deep_sleep_audio(self, frequency=2.5, duration=1800, filename="deep_sleep"):
        """Generate deep sleep audio with very slow binaural beats"""
        print(f"Generating deep sleep audio: {frequency}Hz for {duration}s")
        
        # Use lower sample rate for longer files
        sample_rate = 22050
        num_samples = int(sample_rate * duration)
        left_channel = []
        right_channel = []
        
        # Very slow binaural beats for deep sleep
        base_freq = 200
        left_freq = base_freq
        right_freq = base_freq + frequency
        
        for i in range(num_samples):
            t = i / sample_rate
            
            # Create gentle stereo signal
            left_sample = 0.2 * math.sin(2 * math.pi * left_freq * t)
            right_sample = 0.2 * math.sin(2 * math.pi * right_freq * t)
            
            # Add very subtle harmonics
            left_sample += 0.1 * math.sin(2 * math.pi * left_freq * 0.5 * t)
            right_sample += 0.1 * math.sin(2 * math.pi * right_freq * 0.5 * t)
            
            # Very slow modulation for natural feel
            modulation = 1.0 + 0.02 * math.sin(2 * math.pi * 0.02 * t)
            left_sample *= modulation
            right_sample *= modulation
            
            left_channel.append(left_sample)
            right_channel.append(right_sample)
        
        # Apply very long fade in/out
        left_channel = self.apply_fade(left_channel, 300, 300)  # 5 minutes
        right_channel = self.apply_fade(right_channel, 300, 300)
        
        # Save as WAV with lower sample rate
        output_path = self.dirs['sleep'] / f"{filename}_{frequency}hz.wav"
        
        with wave.open(str(output_path), 'w') as wav_file:
            wav_file.setnchannels(2)
            wav_file.setsampwidth(2)  # 16-bit for compatibility
            wav_file.setframerate(sample_rate)
            
            for i in range(len(left_channel)):
                left_sample = int(left_channel[i] * 32767)
                right_sample = int(right_channel[i] * 32767)
                data = struct.pack('<hh', left_sample, right_sample)
                wav_file.writeframes(data)
        
        print(f"Saved: {output_path}")
        return output_path
    
    def generate_all_audio(self):
        """Generate all high-quality audio files"""
        print("Starting high-quality audio generation for SomnaSync Pro...")
        
        generated_files = []
        
        # Binaural Beats (key frequencies for sleep and meditation)
        print("\n🎵 Generating binaural beats...")
        frequencies = [2.5, 4, 6, 8, 10, 12, 15, 20]
        for freq in frequencies:
            filename = f"binaural_{freq}hz"
            file_path = self.generate_binaural_beats(beat_freq=freq, duration=600, filename=filename)
            generated_files.append(file_path)
        
        # White Noise (all colors)
        print("\n🌊 Generating white noise...")
        colors = ['white', 'pink', 'brown']
        for color in colors:
            filename = f"noise_{color}"
            file_path = self.generate_white_noise(color=color, duration=600, filename=filename)
            generated_files.append(file_path)
        
        # Nature Sounds
        print("\n🌿 Generating nature sounds...")
        nature_sounds = [
            ('ocean_waves', self.generate_ocean_waves),
            ('rain_sounds', self.generate_rain_sounds)
        ]
        
        for name, generator in nature_sounds:
            file_path = generator(duration=600, filename=name)
            generated_files.append(file_path)
        
        # Meditation Audio
        print("\n🧘 Generating meditation audio...")
        meditation_sounds = [
            ('meditation_bells', self.generate_meditation_bells),
            ('breathing_guide', self.generate_breathing_guide)
        ]
        
        for name, generator in meditation_sounds:
            file_path = generator(duration=600, filename=name)
            generated_files.append(file_path)
        
        # Ambient Music
        print("\n🎼 Generating ambient music...")
        ambient_sounds = [
            ('ambient_drone', self.generate_ambient_drone)
        ]
        
        for name, generator in ambient_sounds:
            file_path = generator(duration=600, filename=name)
            generated_files.append(file_path)
        
        # Deep Sleep Audio
        print("\n😴 Generating deep sleep audio...")
        deep_sleep_freqs = [2.5, 4, 6]
        for freq in deep_sleep_freqs:
            file_path = self.generate_deep_sleep_audio(frequency=freq, duration=1800, filename=f"deep_sleep_{freq}hz")
            generated_files.append(file_path)
        
        print(f"\n✨ Audio generation complete! Generated {len(generated_files)} high-quality files.")
        
        # Create summary file
        self._create_summary_file(generated_files)
        
        return generated_files
    
    def _create_summary_file(self, generated_files):
        """Create a detailed summary file"""
        summary_path = self.output_dir / "AUDIO_SUMMARY.txt"
        
        with open(summary_path, 'w') as f:
            f.write("SomnaSync Pro - High Quality Audio Files\n")
            f.write("========================================\n\n")
            f.write(f"Total files generated: {len(generated_files)}\n")
            f.write(f"Sample rate: {self.sample_rate}Hz\n")
            f.write(f"Bit depth: {self.bit_depth}-bit\n")
            f.write(f"Format: WAV (Stereo)\n\n")
            
            # Group by category
            categories = {}
            for file_path in generated_files:
                category = file_path.parent.name
                if category not in categories:
                    categories[category] = []
                categories[category].append(file_path.name)
            
            for category, files in categories.items():
                f.write(f"{category.upper()}:\n")
                f.write("-" * len(category) + "\n")
                for file_name in sorted(files):
                    f.write(f"  - {file_name}\n")
                f.write("\n")
            
            f.write("\nAudio Quality Features:\n")
            f.write("======================\n")
            f.write("✅ High sample rate (48kHz)\n")
            f.write("✅ 24-bit depth for superior quality\n")
            f.write("✅ Smooth fade in/out transitions\n")
            f.write("✅ Stereo spatial effects\n")
            f.write("✅ Natural modulation and variation\n")
            f.write("✅ Professional-grade algorithms\n\n")
            
            f.write("Usage Instructions:\n")
            f.write("==================\n")
            f.write("1. Copy audio files to your Xcode project\n")
            f.write("2. Add to app bundle in Xcode\n")
            f.write("3. Reference in AudioGenerationEngine.swift\n")
            f.write("4. Test playback in your app\n\n")
            
            f.write("Recommended Integration:\n")
            f.write("=======================\n")
            f.write("- Use AVAudioPlayer for playback\n")
            f.write("- Implement crossfading between tracks\n")
            f.write("- Add volume control and EQ\n")
            f.write("- Consider spatial audio for iOS 14+\n")
        
        print(f"📋 Summary file created: {summary_path}")

def main():
    # Create high-quality audio generator
    generator = QualityAudioGenerator()
    
    # Generate all audio files
    generated_files = generator.generate_all_audio()
    
    print(f"\n🎵 High-quality audio generation complete!")
    print(f"📁 Files saved to: {generator.output_dir}")
    print(f"📊 Total files: {len(generated_files)}")
    print(f"📋 Summary: {generator.output_dir}/AUDIO_SUMMARY.txt")
    print(f"\n🚀 Ready for Xcode integration!")

if __name__ == "__main__":
    main() 