import XCTest
import HealthKit
import AVFoundation
@testable import SomnaSync

final class SomnaSyncTests: XCTestCase {
    
    // MARK: - Test Properties
    var sleepManager: SleepManager!
    var healthKitManager: HealthKitManager!
    var audioEngine: AudioGenerationEngine!
    var aiEngine: AISleepAnalysisEngine!
    var smartAlarm: SmartAlarmSystem!
    var appConfig: AppConfiguration!
    
    // MARK: - Setup and Teardown
    override func setUpWithError() throws {
        try super.setUpWithError()
        
        // Initialize managers
        sleepManager = SleepManager.shared
        healthKitManager = HealthKitManager.shared
        audioEngine = AudioGenerationEngine.shared
        aiEngine = AISleepAnalysisEngine.shared
        smartAlarm = SmartAlarmSystem.shared
        appConfig = AppConfiguration.shared
        
        // Reset to test state
        appConfig.resetToDefaults()
    }
    
    override func tearDownWithError() throws {
        // Clean up test data
        sleepManager = nil
        healthKitManager = nil
        audioEngine = nil
        aiEngine = nil
        smartAlarm = nil
        appConfig = nil
        
        try super.tearDownWithError()
    }
    
    // MARK: - Sleep Manager Tests
    
    func testSleepSessionLifecycle() async throws {
        // Test starting sleep session
        await sleepManager.startSleepSession()
        XCTAssertTrue(sleepManager.isMonitoring)
        XCTAssertNotNil(sleepManager.sessionStartTime)
        XCTAssertEqual(sleepManager.currentSleepStage, .awake)
        
        // Test updating sleep stage
        await sleepManager.updateSleepStage(.light)
        XCTAssertEqual(sleepManager.currentSleepStage, .light)
        
        // Test ending sleep session
        let analysis = await sleepManager.endSleepSession()
        XCTAssertFalse(sleepManager.isMonitoring)
        XCTAssertNotNil(analysis)
        XCTAssertNotNil(analysis.session.endTime)
    }
    
    func testSleepStageTransitions() async throws {
        await sleepManager.startSleepSession()
        
        // Test valid transitions
        await sleepManager.updateSleepStage(.light)
        XCTAssertEqual(sleepManager.currentSleepStage, .light)
        
        await sleepManager.updateSleepStage(.deep)
        XCTAssertEqual(sleepManager.currentSleepStage, .deep)
        
        await sleepManager.updateSleepStage(.rem)
        XCTAssertEqual(sleepManager.currentSleepStage, .rem)
        
        await sleepManager.updateSleepStage(.awake)
        XCTAssertEqual(sleepManager.currentSleepStage, .awake)
        
        await sleepManager.endSleepSession()
    }
    
    func testSleepDataPersistence() async throws {
        await sleepManager.startSleepSession()
        
        // Add some sleep stage history
        await sleepManager.updateSleepStage(.light)
        await sleepManager.updateSleepStage(.deep)
        await sleepManager.updateSleepStage(.rem)
        
        let analysis = await sleepManager.endSleepSession()
        
        // Verify data persistence
        XCTAssertGreaterThan(sleepManager.sleepHistory.count, 0)
        XCTAssertEqual(sleepManager.sleepHistory.last?.sleepStage, .rem)
        XCTAssertNotNil(analysis.session.endTime)
    }
    
    // MARK: - Audio Generation Tests
    
    func testBinauralBeatsGeneration() async throws {
        let frequency = 6.0
        let duration: TimeInterval = 60 // 1 minute for testing
        
        let buffer = await audioEngine.generateEnhancedBinauralBeats(
            frequency: frequency,
            duration: duration
        )
        
        XCTAssertNotNil(buffer)
        XCTAssertGreaterThan(buffer.frameLength, 0)
        XCTAssertEqual(buffer.format.sampleRate, 48000, accuracy: 1000)
        XCTAssertEqual(buffer.format.channelCount, 2)
    }
    
    func testWhiteNoiseGeneration() async throws {
        let colors: [NoiseColor] = [.white, .pink, .brown]
        
        for color in colors {
            let buffer = await audioEngine.generateEnhancedWhiteNoise(
                color: color,
                duration: 30
            )
            
            XCTAssertNotNil(buffer)
            XCTAssertGreaterThan(buffer.frameLength, 0)
        }
    }
    
    func testNatureSoundsGeneration() async throws {
        let environments: [NatureEnvironment] = [.ocean, .forest, .rain, .stream, .wind]
        
        for environment in environments {
            let buffer = await audioEngine.generateEnhancedNatureSounds(
                environment: environment,
                duration: 30
            )
            
            XCTAssertNotNil(buffer)
            XCTAssertGreaterThan(buffer.frameLength, 0)
        }
    }
    
    func testCustomSoundscapeCreation() async throws {
        let layers = [
            AudioLayer(type: .binauralBeats, volume: 0.5),
            AudioLayer(type: .natureSounds, volume: 0.3),
            AudioLayer(type: .whiteNoise, volume: 0.2)
        ]
        
        let soundscape = await audioEngine.createCustomSoundscape(layers: layers)
        
        XCTAssertNotNil(soundscape)
        XCTAssertEqual(soundscape.layers.count, 3)
        XCTAssertEqual(soundscape.duration, 28800) // 8 hours
    }
    
    func testAudioQualitySettings() async throws {
        // Test different audio quality settings
        let qualities: [AudioQuality] = [.low, .medium, .high]
        
        for quality in qualities {
            audioEngine.audioQuality = quality
            let buffer = await audioEngine.generateEnhancedBinauralBeats(
                frequency: 6.0,
                duration: 30
            )
            
            XCTAssertNotNil(buffer)
            // Verify quality affects sample rate
            switch quality {
            case .low:
                XCTAssertLessThanOrEqual(buffer.format.sampleRate, 22050)
            case .medium:
                XCTAssertLessThanOrEqual(buffer.format.sampleRate, 44100)
            case .high:
                XCTAssertGreaterThanOrEqual(buffer.format.sampleRate, 48000)
            }
        }
    }
    
    // MARK: - AI Analysis Tests
    
    func testSleepStagePrediction() async throws {
        let biometricData = BiometricData(
            heartRate: 60.0,
            heartRateVariability: 50.0,
            movement: 0.1,
            respiratoryRate: 12.0,
            oxygenSaturation: 98.0,
            temperature: 36.8,
            sleepStage: nil
        )
        
        let prediction = await aiEngine.predictSleepStage(biometricData)
        
        XCTAssertNotNil(prediction)
        XCTAssertGreaterThanOrEqual(prediction.confidence, 0.0)
        XCTAssertLessThanOrEqual(prediction.confidence, 1.0)
        XCTAssertNotNil(prediction.sleepStage)
        XCTAssertGreaterThanOrEqual(prediction.sleepQuality, 0.0)
        XCTAssertLessThanOrEqual(prediction.sleepQuality, 1.0)
    }
    
    func testSleepAnalysisGeneration() async throws {
        let session = SleepSession(
            startTime: Date().addingTimeInterval(-28800), // 8 hours ago
            endTime: Date(),
            sleepStage: .awake,
            quality: 0.85,
            cycleCount: 5
        )
        
        let analysis = await aiEngine.analyzeSleepSession(session)
        
        XCTAssertNotNil(analysis)
        XCTAssertEqual(analysis.session.id, session.id)
        XCTAssertGreaterThanOrEqual(analysis.sleepQuality, 0.0)
        XCTAssertLessThanOrEqual(analysis.sleepQuality, 1.0)
        XCTAssertGreaterThanOrEqual(analysis.deepSleepPercentage, 0.0)
        XCTAssertLessThanOrEqual(analysis.deepSleepPercentage, 1.0)
        XCTAssertGreaterThanOrEqual(analysis.remSleepPercentage, 0.0)
        XCTAssertLessThanOrEqual(analysis.remSleepPercentage, 1.0)
    }
    
    func testRecommendationGeneration() async throws {
        let prediction = SleepStagePrediction(
            sleepStage: .light,
            confidence: 0.8,
            sleepQuality: 0.7
        )
        
        let biometricData = BiometricData(
            heartRate: 65.0,
            heartRateVariability: 45.0,
            movement: 0.2,
            respiratoryRate: 14.0,
            oxygenSaturation: 97.0,
            temperature: 37.0
        )
        
        let recommendations = await aiEngine.generatePersonalizedRecommendations(
            for: prediction,
            with: biometricData
        )
        
        XCTAssertNotNil(recommendations)
        XCTAssertGreaterThan(recommendations.count, 0)
        
        for recommendation in recommendations {
            XCTAssertFalse(recommendation.title.isEmpty)
            XCTAssertFalse(recommendation.description.isEmpty)
            XCTAssertNotNil(recommendation.category)
            XCTAssertNotNil(recommendation.priority)
        }
    }
    
    // MARK: - Smart Alarm Tests
    
    func testOptimalWakeTimePrediction() async throws {
        let targetTime = Date().addingTimeInterval(28800) // 8 hours from now
        let currentState = SleepState(
            isAsleep: true,
            currentStage: .deep,
            sleepQuality: 0.8,
            timeInStage: 1800, // 30 minutes
            cycleNumber: 2
        )
        
        let prediction = await smartAlarm.predictSleepCycles(
            currentState: currentState,
            targetTime: targetTime,
            userHistory: []
        )
        
        XCTAssertNotNil(prediction)
        XCTAssertNotNil(prediction.optimalWakeTime)
        XCTAssertGreaterThan(prediction.confidence, 0.0)
        XCTAssertLessThanOrEqual(prediction.confidence, 1.0)
    }
    
    func testAlarmScheduling() async throws {
        let wakeTime = Date().addingTimeInterval(3600) // 1 hour from now
        
        await smartAlarm.setSmartAlarm(for: wakeTime)
        
        // Verify alarm is scheduled
        XCTAssertTrue(smartAlarm.isAlarmSet)
        XCTAssertNotNil(smartAlarm.scheduledWakeTime)
        
        // Test alarm cancellation
        await smartAlarm.cancelAlarm()
        XCTAssertFalse(smartAlarm.isAlarmSet)
        XCTAssertNil(smartAlarm.scheduledWakeTime)
    }
    
    // MARK: - Configuration Tests
    
    func testConfigurationPersistence() throws {
        // Test default values
        XCTAssertTrue(appConfig.isFirstLaunch)
        XCTAssertFalse(appConfig.hasCompletedOnboarding)
        XCTAssertEqual(appConfig.sleepGoal, 28800) // 8 hours
        
        // Test value changes
        appConfig.isFirstLaunch = false
        appConfig.hasCompletedOnboarding = true
        appConfig.sleepGoal = 32400 // 9 hours
        
        // Verify persistence
        XCTAssertFalse(appConfig.isFirstLaunch)
        XCTAssertTrue(appConfig.hasCompletedOnboarding)
        XCTAssertEqual(appConfig.sleepGoal, 32400)
    }
    
    func testConfigurationExportImport() throws {
        // Set some custom values
        appConfig.sleepGoal = 36000 // 10 hours
        appConfig.audioQuality = .high
        appConfig.spatialAudioEnabled = false
        
        // Export configuration
        guard let exportData = appConfig.exportConfiguration() else {
            XCTFail("Failed to export configuration")
            return
        }
        
        // Reset to defaults
        appConfig.resetToDefaults()
        XCTAssertEqual(appConfig.sleepGoal, 28800)
        XCTAssertEqual(appConfig.audioQuality, .high)
        XCTAssertTrue(appConfig.spatialAudioEnabled)
        
        // Import configuration
        let importSuccess = appConfig.importConfiguration(from: exportData)
        XCTAssertTrue(importSuccess)
        
        // Verify imported values
        XCTAssertEqual(appConfig.sleepGoal, 36000)
        XCTAssertEqual(appConfig.audioQuality, .high)
        XCTAssertFalse(appConfig.spatialAudioEnabled)
    }
    
    // MARK: - Data Model Tests
    
    func testBiometricDataEncoding() throws {
        let biometricData = BiometricData(
            heartRate: 65.0,
            heartRateVariability: 45.0,
            movement: 0.2,
            respiratoryRate: 14.0,
            oxygenSaturation: 97.0,
            temperature: 37.0,
            sleepStage: .light
        )
        
        // Test encoding
        let encoder = JSONEncoder()
        let data = try encoder.encode(biometricData)
        
        // Test decoding
        let decoder = JSONDecoder()
        let decodedData = try decoder.decode(BiometricData.self, from: data)
        
        XCTAssertEqual(biometricData.heartRate, decodedData.heartRate, accuracy: 0.01)
        XCTAssertEqual(biometricData.heartRateVariability, decodedData.heartRateVariability, accuracy: 0.01)
        XCTAssertEqual(biometricData.movement, decodedData.movement, accuracy: 0.01)
        XCTAssertEqual(biometricData.respiratoryRate, decodedData.respiratoryRate, accuracy: 0.01)
        XCTAssertEqual(biometricData.oxygenSaturation, decodedData.oxygenSaturation, accuracy: 0.01)
        XCTAssertEqual(biometricData.temperature, decodedData.temperature, accuracy: 0.01)
        XCTAssertEqual(biometricData.sleepStage, decodedData.sleepStage)
    }
    
    func testSleepSessionEncoding() throws {
        let session = SleepSession(
            startTime: Date(),
            endTime: Date().addingTimeInterval(28800),
            sleepStage: .deep,
            quality: 0.85,
            cycleCount: 5
        )
        
        // Test encoding
        let encoder = JSONEncoder()
        let data = try encoder.encode(session)
        
        // Test decoding
        let decoder = JSONDecoder()
        let decodedSession = try decoder.decode(SleepSession.self, from: data)
        
        XCTAssertEqual(session.id, decodedSession.id)
        XCTAssertEqual(session.startTime.timeIntervalSince1970, decodedSession.startTime.timeIntervalSince1970, accuracy: 1.0)
        XCTAssertEqual(session.endTime?.timeIntervalSince1970, decodedSession.endTime?.timeIntervalSince1970, accuracy: 1.0)
        XCTAssertEqual(session.sleepStage, decodedSession.sleepStage)
        XCTAssertEqual(session.quality, decodedSession.quality, accuracy: 0.01)
        XCTAssertEqual(session.cycleCount, decodedSession.cycleCount)
    }
    
    // MARK: - Performance Tests
    
    func testAudioGenerationPerformance() throws {
        measure {
            let expectation = XCTestExpectation(description: "Audio generation")
            
            Task {
                await audioEngine.generateEnhancedBinauralBeats(
                    frequency: 6.0,
                    duration: 60
                )
                expectation.fulfill()
            }
            
            wait(for: [expectation], timeout: 10.0)
        }
    }
    
    func testSleepAnalysisPerformance() throws {
        let session = SleepSession(
            startTime: Date().addingTimeInterval(-28800),
            endTime: Date(),
            sleepStage: .awake,
            quality: 0.85,
            cycleCount: 5
        )
        
        measure {
            let expectation = XCTestExpectation(description: "Sleep analysis")
            
            Task {
                await aiEngine.analyzeSleepSession(session)
                expectation.fulfill()
            }
            
            wait(for: [expectation], timeout: 5.0)
        }
    }
    
    // MARK: - Integration Tests
    
    func testCompleteSleepWorkflow() async throws {
        // Start sleep session
        await sleepManager.startSleepSession()
        XCTAssertTrue(sleepManager.isMonitoring)
        
        // Simulate sleep stages
        await sleepManager.updateSleepStage(.light)
        await sleepManager.updateSleepStage(.deep)
        await sleepManager.updateSleepStage(.rem)
        await sleepManager.updateSleepStage(.light)
        
        // Generate sleep audio
        await audioEngine.generateSleepAudio(
            type: .deepSleep(frequency: 2.5),
            duration: 28800
        )
        
        // End sleep session
        let analysis = await sleepManager.endSleepSession()
        XCTAssertNotNil(analysis)
        XCTAssertFalse(sleepManager.isMonitoring)
        
        // Generate recommendations
        let recommendations = await aiEngine.generatePersonalizedRecommendations(
            for: SleepStagePrediction(
                sleepStage: .awake,
                confidence: 0.9,
                sleepQuality: analysis.sleepQuality
            ),
            with: BiometricData()
        )
        
        XCTAssertGreaterThan(recommendations.count, 0)
    }
    
    func testAudioQualityIntegration() async throws {
        // Test different audio quality settings with various audio types
        let audioTypes: [PreSleepAudioType] = [
            .binauralBeats(frequency: 6.0),
            .whiteNoise(color: .white),
            .natureSounds(environment: .ocean),
            .guidedMeditation(style: .mindfulness)
        ]
        
        for audioType in audioTypes {
            for quality in AudioQuality.allCases {
                audioEngine.audioQuality = quality
                
                let buffer = await audioEngine.generateEnhancedAudioBuffer(
                    for: audioType,
                    duration: 30
                )
                
                XCTAssertNotNil(buffer)
                XCTAssertGreaterThan(buffer.frameLength, 0)
            }
        }
    }
    
    // MARK: - Error Handling Tests
    
    func testInvalidAudioParameters() async throws {
        // Test invalid frequency
        let buffer = await audioEngine.generateEnhancedBinauralBeats(
            frequency: -1.0,
            duration: 30
        )
        
        // Should handle gracefully
        XCTAssertNotNil(buffer)
        
        // Test invalid duration
        let buffer2 = await audioEngine.generateEnhancedBinauralBeats(
            frequency: 6.0,
            duration: -10
        )
        
        // Should handle gracefully
        XCTAssertNotNil(buffer2)
    }
    
    func testEmptyBiometricData() async throws {
        let emptyData = BiometricData()
        
        let prediction = await aiEngine.predictSleepStage(emptyData)
        
        // Should provide fallback prediction
        XCTAssertNotNil(prediction)
        XCTAssertNotNil(prediction.sleepStage)
    }
    
    // MARK: - Memory Management Tests
    
    func testMemoryUsage() throws {
        let initialMemory = ProcessInfo.processInfo.physicalMemory
        
        // Generate multiple audio buffers
        let expectation = XCTestExpectation(description: "Audio generation")
        
        Task {
            for _ in 0..<10 {
                await audioEngine.generateEnhancedBinauralBeats(
                    frequency: 6.0,
                    duration: 30
                )
            }
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 30.0)
        
        let finalMemory = ProcessInfo.processInfo.physicalMemory
        let memoryIncrease = finalMemory - initialMemory
        
        // Memory increase should be reasonable (less than 100MB)
        XCTAssertLessThan(memoryIncrease, 100 * 1024 * 1024)
    }
    
    // MARK: - Concurrency Tests
    
    func testConcurrentAudioGeneration() async throws {
        let audioTypes: [PreSleepAudioType] = [
            .binauralBeats(frequency: 6.0),
            .whiteNoise(color: .white),
            .natureSounds(environment: .ocean)
        ]
        
        // Generate multiple audio types concurrently
        async let buffers = audioTypes.map { audioType in
            await audioEngine.generateEnhancedAudioBuffer(
                for: audioType,
                duration: 30
            )
        }
        
        let results = await buffers
        
        // All should complete successfully
        for buffer in results {
            XCTAssertNotNil(buffer)
            XCTAssertGreaterThan(buffer.frameLength, 0)
        }
    }
    
    func testConcurrentSleepAnalysis() async throws {
        let sessions = (0..<5).map { _ in
            SleepSession(
                startTime: Date().addingTimeInterval(-28800),
                endTime: Date(),
                sleepStage: .awake,
                quality: Double.random(in: 0.5...1.0),
                cycleCount: Int.random(in: 3...7)
            )
        }
        
        // Analyze multiple sessions concurrently
        async let analyses = sessions.map { session in
            await aiEngine.analyzeSleepSession(session)
        }
        
        let results = await analyses
        
        // All should complete successfully
        for analysis in results {
            XCTAssertNotNil(analysis)
            XCTAssertGreaterThanOrEqual(analysis.sleepQuality, 0.0)
            XCTAssertLessThanOrEqual(analysis.sleepQuality, 1.0)
        }
    }
} 