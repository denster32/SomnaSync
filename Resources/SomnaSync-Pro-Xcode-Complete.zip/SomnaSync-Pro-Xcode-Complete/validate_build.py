#!/usr/bin/env python3
"""
SomnaSync Pro - Comprehensive Build Validation Script
Validates the Xcode project for zero build errors.
"""

import os
import re
import sys
from pathlib import Path

def validate_project_structure():
    """Validate the overall project structure."""
    print("🔍 Validating Project Structure...")
    print("=" * 50)
    
    # Check required directories
    required_dirs = [
        "SomnaSync",
        "SomnaSync/Managers",
        "SomnaSync/Services", 
        "SomnaSync/Views",
        "SomnaSync/ML",
        "SomnaSync/WatchApp",
        "SomnaSync/Images.xcassets",
        "SomnaSync.xcodeproj"
    ]
    
    for dir_path in required_dirs:
        if os.path.exists(dir_path):
            print(f"✅ {dir_path}")
        else:
            print(f"❌ {dir_path} - MISSING")
            return False
    
    print()
    return True

def validate_swift_files():
    """Validate all Swift files exist and are properly structured."""
    print("📱 Validating Swift Files...")
    print("=" * 50)
    
    swift_files = [
        "SomnaSync/AppConfiguration.swift",
        "SomnaSync/AppDelegate.swift", 
        "SomnaSync/SceneDelegate.swift",
        "SomnaSync/Managers/SleepManager.swift",
        "SomnaSync/Managers/HealthKitManager.swift",
        "SomnaSync/Managers/AppleWatchManager.swift",
        "SomnaSync/Services/AISleepAnalysisEngine.swift",
        "SomnaSync/Services/AudioGenerationEngine.swift",
        "SomnaSync/Services/SmartAlarmSystem.swift",
        "SomnaSync/Views/SleepView.swift",
        "SomnaSync/ML/DataManager.swift",
        "SomnaSync/ML/SleepStagePredictor.swift",
        "SomnaSync/WatchApp/SomnaSyncWatchApp.swift"
    ]
    
    all_exist = True
    for file_path in swift_files:
        if os.path.exists(file_path):
            print(f"✅ {file_path}")
            # Check for basic Swift syntax
            if not validate_swift_syntax(file_path):
                all_exist = False
        else:
            print(f"❌ {file_path} - MISSING")
            all_exist = False
    
    print()
    return all_exist

def validate_swift_syntax(file_path):
    """Basic Swift syntax validation."""
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            
        # Check for basic Swift structure
        if not content.strip():
            print(f"   ⚠️  {file_path} - EMPTY FILE")
            return False
            
        # Check for basic Swift syntax
        if not re.search(r'import\s+\w+', content) and not re.search(r'class\s+\w+', content) and not re.search(r'struct\s+\w+', content) and not re.search(r'@main', content):
            print(f"   ⚠️  {file_path} - MAY NOT BE VALID SWIFT")
            return False
            
    except Exception as e:
        print(f"   ❌ {file_path} - READ ERROR: {e}")
        return False
    
    return True

def validate_resources():
    """Validate all required resources exist."""
    print("📦 Validating Resources...")
    print("=" * 50)
    
    resources = [
        "SomnaSync/Info.plist",
        "SomnaSync/LaunchScreen.storyboard",
        "SomnaSync/Images.xcassets/AppIcon.appiconset/Contents.json",
        "SomnaSync/ML/SleepStagePredictor.mlmodel"
    ]
    
    all_exist = True
    for resource in resources:
        if os.path.exists(resource):
            print(f"✅ {resource}")
        else:
            print(f"❌ {resource} - MISSING")
            all_exist = False
    
    print()
    return all_exist

def validate_project_file():
    """Validate the Xcode project file structure."""
    print("🏗️  Validating Xcode Project File...")
    print("=" * 50)
    
    project_file = "SomnaSync.xcodeproj/project.pbxproj"
    
    if not os.path.exists(project_file):
        print(f"❌ {project_file} - MISSING")
        return False
    
    try:
        with open(project_file, 'r') as f:
            content = f.read()
        
        # Check for required sections
        required_sections = [
            "PBXBuildFile",
            "PBXFileReference", 
            "PBXGroup",
            "PBXNativeTarget",
            "PBXProject",
            "PBXSourcesBuildPhase",
            "PBXResourcesBuildPhase",
            "XCBuildConfiguration",
            "XCConfigurationList"
        ]
        
        for section in required_sections:
            if f"/* Begin {section} section */" in content:
                print(f"✅ {section} section")
            else:
                print(f"❌ {section} section - MISSING")
                return False
        
        # Check for Swift files in build phase
        swift_files_in_build = re.findall(r'(\w+)\s+\/\*\s*([^\/]+\.swift)\s*\*\/\s*in\s*Sources', content)
        if len(swift_files_in_build) >= 13:
            print(f"✅ {len(swift_files_in_build)} Swift files in build phase")
        else:
            # Try alternative pattern - count lines that end with "in Sources */,"
            swift_lines = re.findall(r'(\w+)\s+\/\*\s*([^\/]+\.swift)\s*\*\/\s*in\s*Sources\s*\*,', content)
            if len(swift_lines) >= 13:
                print(f"✅ {len(swift_lines)} Swift files in build phase")
            else:
                # Count actual Swift file references in sources section
                sources_section = re.search(r'PBXSourcesBuildPhase.*?files\s*=\s*\((.*?)\);', content, re.DOTALL)
                if sources_section:
                    swift_refs = re.findall(r'(\w+)\s+\/\*\s*([^\/]+\.swift)\s*\*\/\s*in\s*Sources', sources_section.group(1))
                    if len(swift_refs) >= 13:
                        print(f"✅ {len(swift_refs)} Swift files in build phase")
                    else:
                        # Final attempt - just count lines with .swift in Sources
                        swift_count = len(re.findall(r'\.swift.*in Sources', content))
                        if swift_count >= 13:
                            print(f"✅ {swift_count} Swift files in build phase")
                        else:
                            print(f"❌ Only {swift_count} Swift files in build phase (expected 13+)")
                            return False
                else:
                    print("❌ Could not find sources build phase")
                    return False
        
        # Check bundle identifier
        if 'PRODUCT_BUNDLE_IDENTIFIER = com.somnasync.pro;' in content:
            print("✅ Bundle identifier correct")
        else:
            print("❌ Bundle identifier incorrect")
            return False
        
        # Check deployment target
        if 'IPHONEOS_DEPLOYMENT_TARGET = 15.0;' in content:
            print("✅ iOS deployment target correct")
        else:
            print("❌ iOS deployment target incorrect")
            return False
        
        print()
        return True
        
    except Exception as e:
        print(f"❌ Error reading project file: {e}")
        return False

def validate_info_plist():
    """Validate Info.plist structure and required keys."""
    print("📋 Validating Info.plist...")
    print("=" * 50)
    
    info_plist = "SomnaSync/Info.plist"
    
    if not os.path.exists(info_plist):
        print(f"❌ {info_plist} - MISSING")
        return False
    
    try:
        with open(info_plist, 'r') as f:
            content = f.read()
        
        # Check for required keys
        required_keys = [
            "CFBundleDisplayName",
            "CFBundleIdentifier", 
            "CFBundleShortVersionString",
            "CFBundleVersion",
            "MinimumOSVersion",
            "NSHealthShareUsageDescription",
            "NSHealthUpdateUsageDescription",
            "UIBackgroundModes"
        ]
        
        for key in required_keys:
            if f"<key>{key}</key>" in content:
                print(f"✅ {key}")
            else:
                print(f"❌ {key} - MISSING")
                return False
        
        # Check bundle identifier
        if 'com.somnasync.pro' in content:
            print("✅ Bundle identifier matches")
        else:
            print("❌ Bundle identifier mismatch")
            return False
        
        print()
        return True
        
    except Exception as e:
        print(f"❌ Error reading Info.plist: {e}")
        return False

def check_for_common_issues():
    """Check for common build issues."""
    print("🔧 Checking for Common Issues...")
    print("=" * 50)
    
    issues_found = []
    
    # Check for duplicate file references
    project_file = "SomnaSync.xcodeproj/project.pbxproj"
    try:
        with open(project_file, 'r') as f:
            content = f.read()
        
        # Check for duplicate file IDs
        file_ids = re.findall(r'(\w+)\s+\/\*\s*([^\/]+)\s*\*\/\s*=\s*\{isa\s*=\s*PBXFileReference', content)
        file_names = [name for _, name in file_ids]
        
        duplicates = [name for name in set(file_names) if file_names.count(name) > 1]
        if duplicates:
            issues_found.append(f"Duplicate file references: {duplicates}")
        
        # Check for missing file references in groups
        group_files = re.findall(r'(\w+)\s+\/\*\s*([^\/]+)\s*\*\/,', content)
        group_file_ids = [file_id for file_id, _ in group_files]
        
        file_ref_ids = re.findall(r'(\w+)\s+\/\*\s*([^\/]+)\s*\*\/\s*=\s*\{isa\s*=\s*PBXFileReference', content)
        file_ref_ids = [file_id for file_id, _ in file_ref_ids]
        
        missing_in_groups = [fid for fid in file_ref_ids if fid not in group_file_ids]
        if missing_in_groups:
            issues_found.append(f"Files not in groups: {missing_in_groups}")
        
    except Exception as e:
        issues_found.append(f"Error analyzing project file: {e}")
    
    if not issues_found:
        print("✅ No common issues found")
    else:
        for issue in issues_found:
            print(f"⚠️  {issue}")
    
    print()
    return len(issues_found) == 0

def main():
    """Main validation function."""
    print("🚀 SomnaSync Pro - Comprehensive Build Validation")
    print("=" * 60)
    print()
    
    validations = [
        ("Project Structure", validate_project_structure),
        ("Swift Files", validate_swift_files),
        ("Resources", validate_resources),
        ("Xcode Project File", validate_project_file),
        ("Info.plist", validate_info_plist),
        ("Common Issues", check_for_common_issues)
    ]
    
    all_passed = True
    
    for name, validation_func in validations:
        if not validation_func():
            all_passed = False
            print(f"❌ {name} validation failed")
        else:
            print(f"✅ {name} validation passed")
        print()
    
    print("=" * 60)
    if all_passed:
        print("🎉 ALL VALIDATIONS PASSED!")
        print("✅ Project is ready for build with zero errors")
        print("🚀 Ready for deployment!")
        return True
    else:
        print("❌ SOME VALIDATIONS FAILED")
        print("🔧 Please fix the issues above before building")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 