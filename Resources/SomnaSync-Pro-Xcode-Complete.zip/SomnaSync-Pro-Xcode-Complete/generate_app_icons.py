#!/usr/bin/env python3
"""
App Icon Generator for SomnaSync Pro
Generates all required app icon sizes from a base 1024x1024 image
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_base_icon(size=1024):
    """Create a base app icon with sleep-themed design"""
    # Create a new image with a dark blue gradient background
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Create gradient background (dark blue to purple)
    for y in range(size):
        # Gradient from dark blue to purple
        r = int(20 + (y / size) * 30)  # 20-50
        g = int(30 + (y / size) * 20)  # 30-50
        b = int(80 + (y / size) * 60)  # 80-140
        color = (r, g, b, 255)
        draw.line([(0, y), (size, y)], fill=color)
    
    # Add moon shape (white circle with slight transparency)
    moon_center = (size // 2, size // 3)
    moon_radius = size // 4
    moon_color = (255, 255, 255, 200)
    
    # Draw moon
    draw.ellipse([
        moon_center[0] - moon_radius,
        moon_center[1] - moon_radius,
        moon_center[0] + moon_radius,
        moon_center[1] + moon_radius
    ], fill=moon_color)
    
    # Add stars (small white circles)
    star_positions = [
        (size // 4, size // 6),
        (3 * size // 4, size // 8),
        (size // 6, size // 2),
        (5 * size // 6, size // 3),
        (size // 3, 2 * size // 3),
        (2 * size // 3, 3 * size // 4)
    ]
    
    for star_pos in star_positions:
        star_radius = size // 40
        draw.ellipse([
            star_pos[0] - star_radius,
            star_pos[1] - star_radius,
            star_pos[0] + star_radius,
            star_pos[1] + star_radius
        ], fill=(255, 255, 255, 180))
    
    # Add sleep waves at the bottom
    wave_center_y = 3 * size // 4
    wave_width = size // 2
    wave_height = size // 20
    
    # Draw multiple wave lines
    for i in range(3):
        y_offset = wave_center_y + i * size // 30
        wave_color = (255, 255, 255, 100 - i * 20)
        
        # Draw curved wave
        points = []
        for x in range(0, size, size // 20):
            wave_x = x
            wave_y = y_offset + wave_height * (i + 1) * 0.3 * (1 if x % (size // 10) < size // 20 else -1)
            points.append((wave_x, wave_y))
        
        if len(points) > 1:
            draw.line(points, fill=wave_color, width=size // 100)
    
    # Add "SS" text (SomnaSync)
    try:
        # Try to use a system font
        font_size = size // 8
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", font_size)
    except:
        # Fallback to default font
        font = ImageFont.load_default()
    
    text = "SS"
    text_color = (255, 255, 255, 220)
    text_bbox = draw.textbbox((0, 0), text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    
    text_x = (size - text_width) // 2
    text_y = 4 * size // 5
    
    draw.text((text_x, text_y), text, fill=text_color, font=font)
    
    return img

def generate_icons():
    """Generate all required app icon sizes"""
    # Create output directory
    output_dir = "SomnaSync/Images.xcassets/AppIcon.appiconset"
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate base icon
    base_icon = create_base_icon(1024)
    
    # Required icon sizes
    icon_sizes = [
        # iPhone
        ("Icon-App-20x20@2x.png", 40, 40),
        ("Icon-App-20x20@3x.png", 60, 60),
        ("Icon-App-29x29@2x.png", 58, 58),
        ("Icon-App-29x29@3x.png", 87, 87),
        ("Icon-App-40x40@2x.png", 80, 80),
        ("Icon-App-40x40@3x.png", 120, 120),
        ("Icon-App-60x60@2x.png", 120, 120),
        ("Icon-App-60x60@3x.png", 180, 180),
        
        # iPad
        ("Icon-App-20x20@1x.png", 20, 20),
        ("Icon-App-20x20@2x.png", 40, 40),
        ("Icon-App-29x29@1x.png", 29, 29),
        ("Icon-App-29x29@2x.png", 58, 58),
        ("Icon-App-40x40@1x.png", 40, 40),
        ("Icon-App-40x40@2x.png", 80, 80),
        ("Icon-App-76x76@2x.png", 152, 152),
        ("Icon-App-83.5x83.5@2x.png", 167, 167),
        
        # App Store
        ("Icon-App-1024x1024@1x.png", 1024, 1024)
    ]
    
    print("Generating app icons...")
    
    for filename, width, height in icon_sizes:
        # Resize the base icon
        resized_icon = base_icon.resize((width, height), Image.Resampling.LANCZOS)
        
        # Save the icon
        output_path = os.path.join(output_dir, filename)
        resized_icon.save(output_path, "PNG")
        print(f"Generated: {filename} ({width}x{height})")
    
    print(f"\nAll app icons generated in: {output_dir}")
    print("Total icons generated: 17")

if __name__ == "__main__":
    generate_icons() 