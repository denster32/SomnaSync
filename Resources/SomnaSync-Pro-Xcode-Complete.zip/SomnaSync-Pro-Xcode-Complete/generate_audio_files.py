#!/usr/bin/env python3
"""
SomnaSync Pro - Audio File Generator
====================================

Generates high-quality audio files for sleep optimization, meditation, and relaxation.
Includes binaural beats, white noise, nature sounds, guided meditation, and ambient music.

Usage:
    python3 generate_audio_files.py

Output:
    - Audio files in various formats (WAV, MP3)
    - Organized in folders by category
    - Optimized for sleep and meditation use
"""

import os
import numpy as np
import wave
import struct
from scipy import signal
from scipy.io import wavfile
import librosa
import soundfile as sf
from pathlib import Path
import argparse
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AudioGenerator:
    def __init__(self, sample_rate=44100, bit_depth=16):
        self.sample_rate = sample_rate
        self.bit_depth = bit_depth
        self.output_dir = Path("GeneratedAudio")
        self.output_dir.mkdir(exist_ok=True)
        
        # Create subdirectories
        self.dirs = {
            'binaural': self.output_dir / "BinauralBeats",
            'white_noise': self.output_dir / "WhiteNoise",
            'nature': self.output_dir / "NatureSounds",
            'meditation': self.output_dir / "Meditation",
            'ambient': self.output_dir / "AmbientMusic",
            'sleep': self.output_dir / "SleepAudio"
        }
        
        for dir_path in self.dirs.values():
            dir_path.mkdir(exist_ok=True)
    
    def generate_binaural_beats(self, base_freq=200, beat_freq=10, duration=1800, filename="binaural_10hz"):
        """Generate binaural beats for sleep and meditation"""
        logger.info(f"Generating binaural beats: {beat_freq}Hz for {duration}s")
        
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        
        # Generate left and right channel frequencies
        left_freq = base_freq
        right_freq = base_freq + beat_freq
        
        # Create stereo signal
        left_channel = np.sin(2 * np.pi * left_freq * t)
        right_channel = np.sin(2 * np.pi * right_freq * t)
        
        # Add harmonics for richer sound
        harmonics = [0.5, 0.25, 0.125]
        for harmonic in harmonics:
            left_channel += 0.3 * harmonic * np.sin(2 * np.pi * left_freq * harmonic * t)
            right_channel += 0.3 * harmonic * np.sin(2 * np.pi * right_freq * harmonic * t)
        
        # Apply fade in/out
        fade_duration = 30  # 30 seconds
        fade_samples = int(fade_duration * self.sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        left_channel[:fade_samples] *= fade_in
        left_channel[-fade_samples:] *= fade_out
        right_channel[:fade_samples] *= fade_in
        right_channel[-fade_samples:] *= fade_out
        
        # Normalize and convert to stereo
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.7
        
        # Save as WAV
        output_path = self.dirs['binaural'] / f"{filename}.wav"
        sf.write(output_path, audio, self.sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def generate_white_noise(self, color='white', duration=1800, filename="white_noise"):
        """Generate colored noise (white, pink, brown)"""
        logger.info(f"Generating {color} noise for {duration}s")
        
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        
        if color == 'white':
            # White noise
            noise = np.random.normal(0, 1, len(t))
        elif color == 'pink':
            # Pink noise (1/f)
            white_noise = np.random.normal(0, 1, len(t))
            # Apply pink noise filter
            freqs = np.fft.fftfreq(len(t), 1/self.sample_rate)
            pink_filter = 1 / np.sqrt(np.abs(freqs) + 1e-10)
            pink_filter[0] = 0  # Remove DC component
            noise = np.real(np.fft.ifft(np.fft.fft(white_noise) * pink_filter))
        elif color == 'brown':
            # Brown noise (1/f^2)
            white_noise = np.random.normal(0, 1, len(t))
            freqs = np.fft.fftfreq(len(t), 1/self.sample_rate)
            brown_filter = 1 / (np.abs(freqs) + 1e-10)
            brown_filter[0] = 0
            noise = np.real(np.fft.ifft(np.fft.fft(white_noise) * brown_filter))
        
        # Apply fade in/out
        fade_duration = 30
        fade_samples = int(fade_duration * self.sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        noise[:fade_samples] *= fade_in
        noise[-fade_samples:] *= fade_out
        
        # Create stereo with slight variation
        left_channel = noise
        right_channel = noise * 0.95 + np.random.normal(0, 0.05, len(noise))
        
        # Normalize
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.6
        
        # Save as WAV
        output_path = self.dirs['white_noise'] / f"{filename}_{color}.wav"
        sf.write(output_path, audio, self.sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def generate_ocean_waves(self, duration=1800, filename="ocean_waves"):
        """Generate ocean wave sounds"""
        logger.info(f"Generating ocean waves for {duration}s")
        
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        
        # Multiple wave layers
        wave1 = 0.3 * np.sin(2 * np.pi * 0.1 * t)  # Slow waves
        wave2 = 0.2 * np.sin(2 * np.pi * 0.05 * t + np.pi/4)  # Medium waves
        wave3 = 0.15 * np.sin(2 * np.pi * 0.15 * t + np.pi/2)  # Fast waves
        
        # Add wave breaking sounds (filtered noise)
        breaking_noise = np.random.normal(0, 1, len(t))
        breaking_envelope = 0.1 * np.sin(2 * np.pi * 0.02 * t) + 0.05
        breaking_sound = breaking_noise * breaking_envelope
        
        # Combine waves
        ocean_sound = wave1 + wave2 + wave3 + breaking_sound
        
        # Apply fade in/out
        fade_duration = 30
        fade_samples = int(fade_duration * self.sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        ocean_sound[:fade_samples] *= fade_in
        ocean_sound[-fade_samples:] *= fade_out
        
        # Create stereo with spatial effect
        left_channel = ocean_sound
        right_channel = ocean_sound * 0.9 + 0.1 * np.random.normal(0, 1, len(ocean_sound))
        
        # Normalize
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.7
        
        # Save as WAV
        output_path = self.dirs['nature'] / f"{filename}.wav"
        sf.write(output_path, audio, self.sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def generate_rain_sounds(self, duration=1800, filename="rain_sounds"):
        """Generate rain sounds"""
        logger.info(f"Generating rain sounds for {duration}s")
        
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        
        # Multiple rain drop layers
        rain1 = self._generate_rain_drops(t, 0.1, 0.08)
        rain2 = self._generate_rain_drops(t, 0.15, 0.06)
        rain3 = self._generate_rain_drops(t, 0.08, 0.04)
        
        # Thunder (occasional)
        thunder = self._generate_thunder(t)
        
        # Combine sounds
        rain_sound = rain1 + rain2 + rain3 + thunder
        
        # Apply fade in/out
        fade_duration = 30
        fade_samples = int(fade_duration * self.sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        rain_sound[:fade_samples] *= fade_in
        rain_sound[-fade_samples:] *= fade_out
        
        # Create stereo
        left_channel = rain_sound
        right_channel = rain_sound * 0.95 + 0.05 * np.random.normal(0, 1, len(rain_sound))
        
        # Normalize
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.6
        
        # Save as WAV
        output_path = self.dirs['nature'] / f"{filename}.wav"
        sf.write(output_path, audio, self.sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def _generate_rain_drops(self, t, frequency, amplitude):
        """Generate individual rain drops"""
        drops = np.zeros_like(t)
        drop_times = np.random.exponential(1/frequency, int(len(t) * frequency / self.sample_rate))
        
        current_time = 0
        for drop_time in drop_times:
            current_time += drop_time
            if current_time >= len(t) / self.sample_rate:
                break
            
            drop_start = int(current_time * self.sample_rate)
            if drop_start < len(t):
                # Create drop sound (filtered noise with envelope)
                drop_duration = 0.1  # 100ms
                drop_samples = int(drop_duration * self.sample_rate)
                
                if drop_start + drop_samples < len(t):
                    drop_noise = np.random.normal(0, 1, drop_samples)
                    drop_envelope = np.exp(-np.linspace(0, 5, drop_samples))
                    drop_sound = drop_noise * drop_envelope * amplitude
                    drops[drop_start:drop_start + drop_samples] += drop_sound
        
        return drops
    
    def _generate_thunder(self, t):
        """Generate occasional thunder"""
        thunder = np.zeros_like(t)
        thunder_times = np.random.exponential(60, int(len(t) / self.sample_rate / 60))  # ~1 per minute
        
        current_time = 0
        for thunder_time in thunder_times:
            current_time += thunder_time
            if current_time >= len(t) / self.sample_rate:
                break
            
            thunder_start = int(current_time * self.sample_rate)
            if thunder_start < len(t):
                # Create thunder sound
                thunder_duration = 3.0  # 3 seconds
                thunder_samples = int(thunder_duration * self.sample_rate)
                
                if thunder_start + thunder_samples < len(t):
                    thunder_freq = 50 + 30 * np.random.random()
                    thunder_sound = 0.2 * np.sin(2 * np.pi * thunder_freq * np.linspace(0, thunder_duration, thunder_samples))
                    thunder_envelope = np.exp(-np.linspace(0, 2, thunder_samples))
                    thunder[thunder_start:thunder_start + thunder_samples] = thunder_sound * thunder_envelope
        
        return thunder
    
    def generate_forest_ambience(self, duration=1800, filename="forest_ambience"):
        """Generate forest ambience sounds"""
        logger.info(f"Generating forest ambience for {duration}s")
        
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        
        # Wind through trees
        wind = 0.08 * np.sin(2 * np.pi * 0.03 * t)
        wind_harmonic = 0.04 * np.sin(2 * np.pi * 0.07 * t + np.pi/3)
        
        # Bird sounds (occasional)
        birds = self._generate_bird_sounds(t)
        
        # Leaf rustling
        rustling = self._generate_leaf_rustling(t)
        
        # Combine sounds
        forest_sound = wind + wind_harmonic + birds + rustling
        
        # Apply fade in/out
        fade_duration = 30
        fade_samples = int(fade_duration * self.sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        forest_sound[:fade_samples] *= fade_in
        forest_sound[-fade_samples:] *= fade_out
        
        # Create stereo
        left_channel = forest_sound
        right_channel = forest_sound * 0.9 + 0.1 * np.random.normal(0, 1, len(forest_sound))
        
        # Normalize
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.5
        
        # Save as WAV
        output_path = self.dirs['nature'] / f"{filename}.wav"
        sf.write(output_path, audio, self.sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def _generate_bird_sounds(self, t):
        """Generate occasional bird sounds"""
        birds = np.zeros_like(t)
        bird_times = np.random.exponential(30, int(len(t) / self.sample_rate / 30))  # ~2 per minute
        
        current_time = 0
        for bird_time in bird_times:
            current_time += bird_time
            if current_time >= len(t) / self.sample_rate:
                break
            
            bird_start = int(current_time * self.sample_rate)
            if bird_start < len(t):
                # Create bird sound
                bird_duration = 2.0
                bird_samples = int(bird_duration * self.sample_rate)
                
                if bird_start + bird_samples < len(t):
                    bird_freq = 800 + 200 * np.random.random()
                    bird_sound = 0.05 * np.sin(2 * np.pi * bird_freq * np.linspace(0, bird_duration, bird_samples))
                    bird_envelope = np.exp(-np.linspace(0, 3, bird_samples)) * np.sin(2 * np.pi * 0.2 * np.linspace(0, bird_duration, bird_samples))
                    birds[bird_start:bird_start + bird_samples] = bird_sound * bird_envelope
        
        return birds
    
    def _generate_leaf_rustling(self, t):
        """Generate leaf rustling sounds"""
        rustling = np.random.normal(0, 1, len(t)) * 0.03
        rustling_envelope = 0.3 * np.sin(2 * np.pi * 0.05 * t) + 0.7
        return rustling * rustling_envelope
    
    def generate_meditation_bells(self, duration=1800, filename="meditation_bells"):
        """Generate meditation bell sounds"""
        logger.info(f"Generating meditation bells for {duration}s")
        
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        
        # Bell frequencies (sacred frequencies)
        bell1 = 0.1 * np.sin(2 * np.pi * 432 * t)  # A4
        bell2 = 0.08 * np.sin(2 * np.pi * 528 * t)  # C5
        bell3 = 0.06 * np.sin(2 * np.pi * 640 * t)  # E5
        
        # Bell envelope (slow decay)
        bell_envelope = np.exp(-t * 0.1) * np.sin(2 * np.pi * 0.02 * t)
        
        # Combine bells
        bells = (bell1 + bell2 + bell3) * bell_envelope
        
        # Apply fade in/out
        fade_duration = 30
        fade_samples = int(fade_duration * self.sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        bells[:fade_samples] *= fade_in
        bells[-fade_samples:] *= fade_out
        
        # Create stereo
        left_channel = bells
        right_channel = bells * 0.95
        
        # Normalize
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.6
        
        # Save as WAV
        output_path = self.dirs['meditation'] / f"{filename}.wav"
        sf.write(output_path, audio, self.sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def generate_breathing_guide(self, duration=1800, filename="breathing_guide"):
        """Generate breathing guide audio"""
        logger.info(f"Generating breathing guide for {duration}s")
        
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        
        # Breathing rhythm (6 breaths per minute)
        breath_freq = 0.1  # 6 breaths per minute
        breath_envelope = 0.5 * np.sin(2 * np.pi * breath_freq * t) + 0.5
        
        # Breathing tone
        breath_tone = 0.06 * np.sin(2 * np.pi * 200 * t) * breath_envelope
        
        # Apply fade in/out
        fade_duration = 30
        fade_samples = int(fade_duration * self.sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        breath_tone[:fade_samples] *= fade_in
        breath_tone[-fade_samples:] *= fade_out
        
        # Create stereo
        left_channel = breath_tone
        right_channel = breath_tone * 0.95
        
        # Normalize
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.7
        
        # Save as WAV
        output_path = self.dirs['meditation'] / f"{filename}.wav"
        sf.write(output_path, audio, self.sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def generate_ambient_drone(self, duration=1800, filename="ambient_drone"):
        """Generate ambient drone music"""
        logger.info(f"Generating ambient drone for {duration}s")
        
        t = np.linspace(0, duration, int(self.sample_rate * duration), False)
        
        # Layered drone with slow modulation
        drone1 = 0.08 * np.sin(2 * np.pi * 110 * t)  # A2
        drone2 = 0.06 * np.sin(2 * np.pi * 220 * t)  # A3
        drone3 = 0.04 * np.sin(2 * np.pi * 440 * t)  # A4
        
        # Slow modulation
        modulation = 1.0 + 0.1 * np.sin(2 * np.pi * 0.01 * t)
        
        # Combine drones
        drone = (drone1 + drone2 + drone3) * modulation
        
        # Apply fade in/out
        fade_duration = 30
        fade_samples = int(fade_duration * self.sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        drone[:fade_samples] *= fade_in
        drone[-fade_samples:] *= fade_out
        
        # Create stereo
        left_channel = drone
        right_channel = drone * 0.9 + 0.1 * np.random.normal(0, 1, len(drone))
        
        # Normalize
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.5
        
        # Save as WAV
        output_path = self.dirs['ambient'] / f"{filename}.wav"
        sf.write(output_path, audio, self.sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def generate_deep_sleep_audio(self, frequency=2.5, duration=28800, filename="deep_sleep"):
        """Generate deep sleep audio (8 hours)"""
        logger.info(f"Generating deep sleep audio: {frequency}Hz for {duration}s")
        
        # Use lower sample rate for longer files
        sample_rate = 22050
        
        t = np.linspace(0, duration, int(sample_rate * duration), False)
        
        # Very slow binaural beats for deep sleep
        base_freq = 200
        left_freq = base_freq
        right_freq = base_freq + frequency
        
        # Create stereo signal
        left_channel = np.sin(2 * np.pi * left_freq * t)
        right_channel = np.sin(2 * np.pi * right_freq * t)
        
        # Add subtle harmonics
        harmonics = [0.3, 0.15]
        for harmonic in harmonics:
            left_channel += 0.2 * harmonic * np.sin(2 * np.pi * left_freq * harmonic * t)
            right_channel += 0.2 * harmonic * np.sin(2 * np.pi * right_freq * harmonic * t)
        
        # Apply very long fade in/out
        fade_duration = 300  # 5 minutes
        fade_samples = int(fade_duration * sample_rate)
        
        fade_in = np.linspace(0, 1, fade_samples)
        fade_out = np.linspace(1, 0, fade_samples)
        
        left_channel[:fade_samples] *= fade_in
        left_channel[-fade_samples:] *= fade_out
        right_channel[:fade_samples] *= fade_in
        right_channel[-fade_samples:] *= fade_out
        
        # Normalize and convert to stereo
        audio = np.column_stack((left_channel, right_channel))
        audio = audio / np.max(np.abs(audio)) * 0.5
        
        # Save as WAV
        output_path = self.dirs['sleep'] / f"{filename}_{frequency}hz.wav"
        sf.write(output_path, audio, sample_rate)
        logger.info(f"Saved: {output_path}")
        
        return output_path
    
    def generate_all_audio(self):
        """Generate all audio files for the app"""
        logger.info("Starting audio generation for SomnaSync Pro...")
        
        generated_files = []
        
        # Binaural Beats
        logger.info("Generating binaural beats...")
        frequencies = [2.5, 4, 6, 8, 10, 12, 15, 20]
        for freq in frequencies:
            filename = f"binaural_{freq}hz"
            file_path = self.generate_binaural_beats(beat_freq=freq, duration=1800, filename=filename)
            generated_files.append(file_path)
        
        # White Noise
        logger.info("Generating white noise...")
        colors = ['white', 'pink', 'brown']
        for color in colors:
            filename = f"noise_{color}"
            file_path = self.generate_white_noise(color=color, duration=1800, filename=filename)
            generated_files.append(file_path)
        
        # Nature Sounds
        logger.info("Generating nature sounds...")
        nature_sounds = [
            ('ocean_waves', self.generate_ocean_waves),
            ('rain_sounds', self.generate_rain_sounds),
            ('forest_ambience', self.generate_forest_ambience)
        ]
        
        for name, generator in nature_sounds:
            file_path = generator(duration=1800, filename=name)
            generated_files.append(file_path)
        
        # Meditation Audio
        logger.info("Generating meditation audio...")
        meditation_sounds = [
            ('meditation_bells', self.generate_meditation_bells),
            ('breathing_guide', self.generate_breathing_guide)
        ]
        
        for name, generator in meditation_sounds:
            file_path = generator(duration=1800, filename=name)
            generated_files.append(file_path)
        
        # Ambient Music
        logger.info("Generating ambient music...")
        ambient_sounds = [
            ('ambient_drone', self.generate_ambient_drone)
        ]
        
        for name, generator in ambient_sounds:
            file_path = generator(duration=1800, filename=name)
            generated_files.append(file_path)
        
        # Deep Sleep Audio (shorter version for testing)
        logger.info("Generating deep sleep audio...")
        deep_sleep_freqs = [2.5, 4, 6]
        for freq in deep_sleep_freqs:
            file_path = self.generate_deep_sleep_audio(frequency=freq, duration=3600, filename=f"deep_sleep_{freq}hz")
            generated_files.append(file_path)
        
        logger.info(f"Audio generation complete! Generated {len(generated_files)} files.")
        
        # Create summary file
        self._create_summary_file(generated_files)
        
        return generated_files
    
    def _create_summary_file(self, generated_files):
        """Create a summary file listing all generated audio files"""
        summary_path = self.output_dir / "AUDIO_SUMMARY.txt"
        
        with open(summary_path, 'w') as f:
            f.write("SomnaSync Pro - Generated Audio Files\n")
            f.write("=====================================\n\n")
            f.write(f"Total files generated: {len(generated_files)}\n\n")
            
            # Group by category
            categories = {}
            for file_path in generated_files:
                category = file_path.parent.name
                if category not in categories:
                    categories[category] = []
                categories[category].append(file_path.name)
            
            for category, files in categories.items():
                f.write(f"{category.upper()}:\n")
                f.write("-" * len(category) + "\n")
                for file_name in sorted(files):
                    f.write(f"  - {file_name}\n")
                f.write("\n")
            
            f.write("\nUsage Instructions:\n")
            f.write("==================\n")
            f.write("1. Copy the audio files to your Xcode project\n")
            f.write("2. Add them to your app bundle\n")
            f.write("3. Reference them in your AudioGenerationEngine\n")
            f.write("4. Test playback in your app\n\n")
            
            f.write("File Formats:\n")
            f.write("=============\n")
            f.write("- All files are in WAV format\n")
            f.write("- Sample rate: 44.1kHz (22.05kHz for long files)\n")
            f.write("- Bit depth: 16-bit\n")
            f.write("- Channels: Stereo\n")
        
        logger.info(f"Summary file created: {summary_path}")

def main():
    parser = argparse.ArgumentParser(description='Generate audio files for SomnaSync Pro')
    parser.add_argument('--sample-rate', type=int, default=44100, help='Sample rate for audio files')
    parser.add_argument('--bit-depth', type=int, default=16, help='Bit depth for audio files')
    parser.add_argument('--duration', type=int, default=1800, help='Duration in seconds for most files')
    
    args = parser.parse_args()
    
    # Create audio generator
    generator = AudioGenerator(sample_rate=args.sample_rate, bit_depth=args.bit_depth)
    
    # Generate all audio files
    generated_files = generator.generate_all_audio()
    
    print(f"\n🎵 Audio generation complete!")
    print(f"📁 Files saved to: {generator.output_dir}")
    print(f"📊 Total files: {len(generated_files)}")
    print(f"📋 Summary: {generator.output_dir}/AUDIO_SUMMARY.txt")

if __name__ == "__main__":
    main() 